<?php

namespace magichomes\Http\Controllers;

use Illuminate\Http\Request;
use magichomes\Post;
use magichomes\User;
use Session;
use Auth;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function result()
    {


    $posts = Post::where("category", "like", "%".request("query1")."%")
                    ->where("city", "=", request("query2"))
                    ->paginate(4);

        return view('result', ['posts'=>$posts->appends(request()->input())
        ]);

    }

    public function rents()
    {
        $posts = Post::where("category", "like", "rent")
                        ->orderBy('created_at', 'desc')
                        ->paginate(4);
        return view('results', ['posts'=>$posts]);
    }

    public function sells()
    {
        $posts = Post::where("category", "like", "sell")
                        ->orderBy('created_at', 'desc')
                        ->paginate(4);
        return view('results', ['posts'=>$posts]);
    }

    public function index()
    {
        $posts = Post::orderBy('created_at', 'desc')->paginate(10);
        // return view('admin.posts.index')->with('posts', Post::all());
        return view('admin.posts.index', ['posts'=>$posts]);
    }

    public function mypost()
    {
        $user = Auth::id();
        // $posts = Post::where("user_id", "=", $user)->get();
        $posts = Post::where("user_id", "=", $user)
                ->orderBy('created_at', 'desc')
                ->paginate(5);

        // return view('admin.posts.index')->with('posts', $posts);
        return view('admin.posts.index')->with('posts', $posts);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.posts.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $this->validate($request, [
            'category' => 'required',
            'subcategory' => 'required',
            'type' => 'required',
            'construction_status' => 'required',
            'price' => 'required',
            'posted_by' => 'required',
            'project_name' => 'required',
            'state' => 'required',
            'city' => 'required',
            'gallery_one' => 'required|image',
            'gallery_two' => 'required|image',
            'gallery_three' => 'required|image'
         ]);

         $gallery_one = $request->gallery_one;
         $gallery_one_new_name = time().$gallery_one->getClientOriginalName();
         $gallery_one->move('uploads/posts', $gallery_one_new_name);

         $gallery_two = $request->gallery_two;
         $gallery_two_new_name = time().$gallery_two->getClientOriginalName();
         $gallery_two->move('uploads/posts', $gallery_two_new_name);

         $gallery_three = $request->gallery_three;
         $gallery_three_new_name = time().$gallery_three->getClientOriginalName();
         $gallery_three->move('uploads/posts', $gallery_three_new_name);

         $post = Post::create([
            'category' => $request->category,
            'subcategory' => $request->subcategory,
            'type' => $request->type,
            'construction_status' => $request->construction_status,
            'price' => $request->price,
            'posted_by' => $request->posted_by,
            'project_name' => $request->project_name,
            'area' => $request->area,
            'overview' => $request->overview,
            'state' => $request->state,
            'city' => $request->city,
            'street' => $request->street,
            'amenties' => $request->amenties,
            'specification' => $request->specification,
            'gallery_one' => 'uploads/posts/'.$gallery_one_new_name,
            'gallery_two' => 'uploads/posts/'.$gallery_two_new_name,
            'gallery_three' => 'uploads/posts/'.$gallery_three_new_name,
            'slug' => str_slug($request->project_name),
            'user_id' =>Auth::id()
         ]);

         Session::flash('success', 'Post created succesfully.');
         return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $post = Post::find($id);

        return view('admin.posts.edit')->with('post', $post);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'category' => 'required',
            'subcategory' => 'required',
            'type' => 'required',
            'construction_status' => 'required',
            'price' => 'required',
            'posted_by' => 'required',
            'project_name' => 'required',
            'state' => 'required',
            'city' => 'required',
            'street' => 'required'
         ]);
         $post = Post::find($id);

         if($request->hasFile('gallery_one'))
         {
             $gallery_one = $request->gallery_one;
             $gallery_one_new_name = time() . $gallery_one->getClientOriginalName();
             $gallery_one->move('uploads/posts', $gallery_one_new_name);
             $post->gallery_one = 'uploads/posts/'.$gallery_one_new_name;
         }

         if($request->hasFile('gallery_two'))
         {
             $gallery_two = $request->gallery_two;
             $gallery_two_new_name = time() . $gallery_two->getClientOriginalName();
             $gallery_two->move('uploads/posts', $gallery_two_new_name);
             $post->gallery_two = 'uploads/posts/'.$gallery_two_new_name;
         }

         if($request->hasFile('gallery_three'))
         {
             $gallery_three = $request->gallery_three;
             $gallery_three_new_name = time() . $gallery_three->getClientOriginalName();
             $gallery_three->move('uploads/posts', $gallery_three_new_name);
             $post->gallery_three = 'uploads/posts/'.$gallery_three_new_name;
         }

         $post->category = $request->category;
         $post->subcategory = $request->subcategory;
         $post->type = $request->type;
         $post->construction_status = $request->construction_status;
         $post->price = $request->price;
         $post->posted_by = $request->posted_by;
         $post->project_name = $request->project_name;
         $post->area = $request->area;
         $post->overview = $request->overview;
         $post->state = $request->state;
         $post->city = $request->city;
         $post->street = $request->street;
         $post->amenties = $request->amenties;
         $post->specification = $request->specification;

         $post->save();

         Session::flash('success', 'Property updated successfully');

         return redirect()->route('post');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $post = Post::find($id);
        $post->delete();
        Session::flash('success', 'The post was just trashed.');
        return redirect()->back();
    }

    public function trashed() {
        $user = Auth::id();

        $posts = Post::where("user_id", "=", $user)
                        ->orderBy('created_at', 'desc')
                        ->onlyTrashed()
                        ->paginate(10);

        return view('admin.posts.trashed', ['posts'=>$posts]);
    }

    public function kill($id)
    {
        $post =  Post::withTrashed()->where('id', $id)->first();
        
        $post->forceDelete();
        
        Session::flash('success', 'Post deleted permanently.');

        return redirect()->back();
    }

    public function restore($id)
    {
        $post = Post::withTrashed()->where('id', $id)->first();
        $post->restore();
        Session::flash('success', 'Post restored successfully.');
        return redirect()->route('post');
    }
}
